<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Office - PT. Fasadetama Indonesia</title>

    {{-- Preconnect untuk mempercepat koneksi ke CDN --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://cdn.tailwindcss.com">

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Inter', sans-serif; }
        .sidebar-scroll::-webkit-scrollbar { width: 6px; }
        .sidebar-scroll::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 flex h-screen overflow-hidden antialiased">

    {{-- ===== SaaS Toast Notification Container ===== --}}
    <div id="toast-container" class="fixed top-5 right-5 z-[99998] flex flex-col gap-3 pointer-events-none" style="max-width: 420px; width: 100%;"></div>

    <style>
        /* ===== TOAST ANIMATIONS ===== */
        @keyframes toast-slide-in {
            0% { transform: translateX(120%); opacity: 0; }
            60% { transform: translateX(-8px); opacity: 1; }
            100% { transform: translateX(0); opacity: 1; }
        }
        @keyframes toast-fade-out {
            0% { transform: translateX(0); opacity: 1; max-height: 120px; margin-bottom: 12px; }
            100% { transform: translateX(120%); opacity: 0; max-height: 0; margin-bottom: 0; padding: 0; }
        }
        @keyframes toast-progress {
            0% { width: 100%; }
            100% { width: 0%; }
        }
        .toast-item {
            animation: toast-slide-in 0.45s cubic-bezier(0.21, 1.02, 0.73, 1) forwards;
            pointer-events: all;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
        }
        .toast-item.removing {
            animation: toast-fade-out 0.4s cubic-bezier(0.55, 0, 1, 0.45) forwards;
        }
        .toast-progress-bar {
            animation: toast-progress linear forwards;
        }

        /* ===== CONFIRM MODAL ===== */
        #confirm-overlay {
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.2s ease, visibility 0.2s ease;
        }
        #confirm-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        #confirm-dialog {
            transform: scale(0.9) translateY(10px);
            opacity: 0;
            transition: transform 0.25s cubic-bezier(0.21, 1.02, 0.73, 1), opacity 0.2s ease;
        }
        #confirm-overlay.active #confirm-dialog {
            transform: scale(1) translateY(0);
            opacity: 1;
        }
    </style>

    {{-- ===== SaaS Confirmation Modal ===== --}}
    <div id="confirm-overlay" class="fixed inset-0 z-[99999] flex items-center justify-center p-4" style="background: rgba(15,23,42,0.45); backdrop-filter: blur(4px);">
        <div id="confirm-dialog" class="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-[420px] overflow-hidden">
            {{-- Icon Area --}}
            <div class="flex justify-center pt-7 pb-2">
                <div id="confirm-icon-wrap" class="w-14 h-14 rounded-full flex items-center justify-center">
                    <svg id="confirm-icon-svg" class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"></svg>
                </div>
            </div>
            {{-- Text --}}
            <div class="text-center px-7 pb-2">
                <h3 id="confirm-title" class="text-lg font-bold text-slate-800"></h3>
                <p id="confirm-message" class="text-sm text-slate-500 mt-2 leading-relaxed"></p>
            </div>
            {{-- Actions --}}
            <div class="flex gap-3 px-7 pt-4 pb-7">
                <button id="confirm-cancel-btn" onclick="ConfirmModal.cancel()" 
                        class="flex-1 px-4 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors">
                    Batal
                </button>
                <button id="confirm-ok-btn" onclick="ConfirmModal.ok()"
                        class="flex-1 px-4 py-2.5 text-sm font-semibold text-white rounded-xl transition-all shadow-md">
                </button>
            </div>
        </div>
    </div>

    @include('layouts.partials.sidebar')

    <!-- Main Content -->
    <main class="flex-1 overflow-y-auto bg-slate-50">
        @yield('content')
    </main>

    {{-- ===== SaaS Toast Notification Engine ===== --}}
    <script>
        window.Toast = {
            container: null,
            
            config: {
                success: {
                    bg: 'bg-white/95 border-emerald-200',
                    icon: '<svg class="w-5 h-5 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
                    accent: 'bg-emerald-500',
                    title: 'Berhasil!',
                    progressColor: 'bg-emerald-400',
                },
                error: {
                    bg: 'bg-white/95 border-red-200',
                    icon: '<svg class="w-5 h-5 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
                    accent: 'bg-red-500',
                    title: 'Gagal!',
                    progressColor: 'bg-red-400',
                },
                warning: {
                    bg: 'bg-white/95 border-amber-200',
                    icon: '<svg class="w-5 h-5 text-amber-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>',
                    accent: 'bg-amber-500',
                    title: 'Peringatan!',
                    progressColor: 'bg-amber-400',
                },
                info: {
                    bg: 'bg-white/95 border-blue-200',
                    icon: '<svg class="w-5 h-5 text-blue-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>',
                    accent: 'bg-blue-500',
                    title: 'Informasi',
                    progressColor: 'bg-blue-400',
                }
            },

            init() {
                this.container = document.getElementById('toast-container');
            },

            show(type, message, duration = 5000) {
                if (!this.container) this.init();
                const cfg = this.config[type] || this.config.info;

                const toast = document.createElement('div');
                toast.className = `toast-item relative overflow-hidden rounded-xl border shadow-lg shadow-slate-900/5 ${cfg.bg}`;
                toast.innerHTML = `
                    <div class="absolute top-0 left-0 w-1 h-full ${cfg.accent} rounded-l-xl"></div>
                    <div class="flex items-start gap-3 pl-5 pr-4 py-4">
                        ${cfg.icon}
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-semibold text-slate-800">${cfg.title}</p>
                            <p class="text-sm text-slate-600 mt-0.5 leading-relaxed">${message}</p>
                        </div>
                        <button onclick="Toast.dismiss(this.closest('.toast-item'))" 
                                class="flex-shrink-0 p-1 rounded-lg hover:bg-slate-100 transition-colors group">
                            <svg class="w-4 h-4 text-slate-400 group-hover:text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    <div class="absolute bottom-0 left-0 right-0 h-[3px] bg-slate-100/50">
                        <div class="toast-progress-bar h-full ${cfg.progressColor} rounded-full opacity-60" 
                             style="animation-duration: ${duration}ms"></div>
                    </div>
                `;

                this.container.appendChild(toast);

                // Auto dismiss
                const timer = setTimeout(() => this.dismiss(toast), duration);
                toast._timer = timer;

                // Pause on hover
                toast.addEventListener('mouseenter', () => {
                    clearTimeout(toast._timer);
                    const progressBar = toast.querySelector('.toast-progress-bar');
                    if (progressBar) progressBar.style.animationPlayState = 'paused';
                });
                toast.addEventListener('mouseleave', () => {
                    toast._timer = setTimeout(() => this.dismiss(toast), 2000);
                    const progressBar = toast.querySelector('.toast-progress-bar');
                    if (progressBar) {
                        progressBar.style.animationDuration = '2s';
                        progressBar.style.animationPlayState = 'running';
                    }
                });
            },

            dismiss(el) {
                if (!el || el.classList.contains('removing')) return;
                clearTimeout(el._timer);
                el.classList.add('removing');
                el.addEventListener('animationend', () => el.remove());
            },

            success(msg, duration) { this.show('success', msg, duration); },
            error(msg, duration)   { this.show('error', msg, duration); },
            warning(msg, duration) { this.show('warning', msg, duration); },
            info(msg, duration)    { this.show('info', msg, duration); },
        };
    </script>

    {{-- ===== SaaS Confirmation Modal Engine ===== --}}
    <script>
        window.ConfirmModal = {
            _resolve: null,
            _overlay: null,

            variants: {
                danger: {
                    iconBg: 'bg-red-100',
                    iconPath: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>',
                    iconColor: 'text-red-600',
                    btnBg: 'bg-red-600 hover:bg-red-700 shadow-red-500/20',
                    btnText: 'Ya, Hapus',
                },
                warning: {
                    iconBg: 'bg-amber-100',
                    iconPath: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>',
                    iconColor: 'text-amber-600',
                    btnBg: 'bg-amber-500 hover:bg-amber-600 shadow-amber-500/20',
                    btnText: 'Ya, Lanjutkan',
                },
                approve: {
                    iconBg: 'bg-emerald-100',
                    iconPath: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>',
                    iconColor: 'text-emerald-600',
                    btnBg: 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-500/20',
                    btnText: 'Ya, Setujui',
                },
                info: {
                    iconBg: 'bg-blue-100',
                    iconPath: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>',
                    iconColor: 'text-blue-600',
                    btnBg: 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20',
                    btnText: 'Ya, Konfirmasi',
                }
            },

            show({ title = 'Konfirmasi', message = 'Apakah Anda yakin?', variant = 'warning', confirmText = null, cancelText = 'Batal' } = {}) {
                return new Promise((resolve) => {
                    this._resolve = resolve;
                    this._overlay = document.getElementById('confirm-overlay');

                    const v = this.variants[variant] || this.variants.warning;

                    // Set icon
                    const iconWrap = document.getElementById('confirm-icon-wrap');
                    iconWrap.className = `w-14 h-14 rounded-full flex items-center justify-center ${v.iconBg}`;
                    const iconSvg = document.getElementById('confirm-icon-svg');
                    iconSvg.className = `w-7 h-7 ${v.iconColor}`;
                    iconSvg.innerHTML = v.iconPath;

                    // Set text
                    document.getElementById('confirm-title').textContent = title;
                    document.getElementById('confirm-message').textContent = message;

                    // Set buttons
                    const okBtn = document.getElementById('confirm-ok-btn');
                    okBtn.className = `flex-1 px-4 py-2.5 text-sm font-semibold text-white rounded-xl transition-all shadow-md cursor-pointer ${v.btnBg}`;
                    okBtn.textContent = confirmText || v.btnText;

                    document.getElementById('confirm-cancel-btn').textContent = cancelText;

                    // Show
                    this._overlay.classList.add('active');

                    // Close on backdrop click
                    this._overlay.onclick = (e) => {
                        if (e.target === this._overlay) this.cancel();
                    };

                    // Close on Escape
                    this._escHandler = (e) => { if (e.key === 'Escape') this.cancel(); };
                    document.addEventListener('keydown', this._escHandler);
                });
            },

            ok() {
                this._cleanup();
                if (this._resolve) this._resolve(true);
            },

            cancel() {
                this._cleanup();
                if (this._resolve) this._resolve(false);
            },

            _cleanup() {
                if (this._overlay) this._overlay.classList.remove('active');
                if (this._escHandler) document.removeEventListener('keydown', this._escHandler);
            }
        };
    </script>

    {{-- Auto-trigger dari Laravel Session Flash --}}
    @if(session('success'))
        <script>document.addEventListener('DOMContentLoaded', () => Toast.success(@json(session('success'))));</script>
        <script>document.addEventListener('turbo:load', function _s() { Toast.success(@json(session('success'))); document.removeEventListener('turbo:load', _s); });</script>
    @endif
    @if(session('error'))
        <script>document.addEventListener('DOMContentLoaded', () => Toast.error(@json(session('error'))));</script>
        <script>document.addEventListener('turbo:load', function _e() { Toast.error(@json(session('error'))); document.removeEventListener('turbo:load', _e); });</script>
    @endif
    @if(session('warning'))
        <script>document.addEventListener('DOMContentLoaded', () => Toast.warning(@json(session('warning'))));</script>
    @endif
    @if(session('info'))
        <script>document.addEventListener('DOMContentLoaded', () => Toast.info(@json(session('info'))));</script>
    @endif

    {{-- Stack untuk script halaman spesifik --}}
    @stack('scripts')

</body>
</html>
